length = eval(input("Enter the length of the rectangle: "))
breadth = eval(input("Enter the breadth of the rectangle: "))

if (length == breadth):
  print("The rectangle is a square.")
else:
  print("The rectangle is not a square.")